from django.apps import AppConfig


class DeviceinfoConfig(AppConfig):
    name = 'deviceInfo'
